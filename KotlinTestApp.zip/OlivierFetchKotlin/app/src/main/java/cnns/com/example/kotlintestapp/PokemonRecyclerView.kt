package cnns.com.example.kotlintestapp

data class PokemonRecyclerView(var text1: String?, var text2: String?, var id: Int?)

