package cnns.com.example.kotlintestapp.models

data class Pokemon(
    val id: Int? = null,
    val name: String? = null,
    val weight: String? = null
)